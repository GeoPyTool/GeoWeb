from numpy import loadtxt
import numpy as np
file = open('s1.csv', 'rb')
data = np.genfromtxt(file,dtype=None,delimiter = ",",encoding='GBK' ,filling_values=-1 )
print(data)
blank = np.where(data=='')
data[blank] = -1